// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("allocation bench"); }
int main(){
  announce();
  return lionss_run_workload("allocation-bench");
}
