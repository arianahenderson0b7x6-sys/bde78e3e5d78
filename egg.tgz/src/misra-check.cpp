// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("misra check"); }
int main(){
  announce();
  return lionss_run_workload("misra-check");
}
