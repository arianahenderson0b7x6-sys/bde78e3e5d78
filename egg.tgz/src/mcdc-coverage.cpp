// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("mcdc coverage"); }
int main(){
  announce();
  return lionss_run_workload("mcdc-coverage");
}
