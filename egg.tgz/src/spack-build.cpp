// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("spack build"); }
int main(){
  announce();
  return lionss_run_workload("spack-build");
}
