// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("contract tests"); }
int main(){
  announce();
  return lionss_run_workload("contract-tests");
}
