// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("werror build\n", stdout);
  return lionss_run_workload("werror-build");
}
