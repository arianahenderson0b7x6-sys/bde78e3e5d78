// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("hardened runtime\n", stdout);
  return lionss_run_workload("hardened-runtime");
}
